#!/usr/bin/env bash
# ================================================================
# PaoloMind v1.0 — Instalador para Ubuntu 22.04 / 24.04 x86_64
# PaolosSoftware © 2026
# Uso: sudo bash install.sh
# ================================================================
set -e

INSTALL_DIR="/opt/paolosmind"
DATA_DIR="/var/paolosmind"
BIN_PATH="/usr/local/bin/paolosmind"
SERVICE_FILE="/etc/systemd/system/paolosmind.service"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RELEASE_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[PaoloMind]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── Verificar root ────────────────────────────────────────────
[ "$EUID" -ne 0 ] && error "Ejecutar con: sudo bash install.sh"

# ── Verificar Ubuntu ──────────────────────────────────────────
if ! command -v apt &>/dev/null; then
    error "Este instalador es para Ubuntu/Debian"
fi

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║      PaoloMind v1.0 — Instalando...          ║"
echo "║         PaolosSoftware © 2026                ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Dependencias del sistema ──────────────────────────────────
info "Instalando dependencias..."
apt-get update -qq
apt-get install -y -qq \
    curl wget python3 python3-pip \
    tesseract-ocr tesseract-ocr-spa \
    libsqlite3-dev \
    2>/dev/null || warn "Algunos paquetes opcionales no disponibles"

# ── Dependencias Python para bridges ─────────────────────────
info "Instalando bridges Python..."
pip3 install --break-system-packages -q \
    beautifulsoup4 requests yt-dlp \
    opencv-python-headless 2>/dev/null || \
pip3 install -q beautifulsoup4 requests yt-dlp 2>/dev/null || \
    warn "Algunos bridges Python no instalados — funcionalidad reducida"

# ── Crear directorios ─────────────────────────────────────────
info "Creando estructura de directorios..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$DATA_DIR"/{memory,data,logs,bridges,models}

# ── Instalar binario ──────────────────────────────────────────
info "Instalando binario..."
cp "$RELEASE_DIR/bin/paolosmind" "$INSTALL_DIR/paolosmind"
chmod +x "$INSTALL_DIR/paolosmind"
ln -sf "$INSTALL_DIR/paolosmind" "$BIN_PATH"

# ── Instalar datos de conocimiento ────────────────────────────
info "Instalando conocimiento primario..."
cp "$RELEASE_DIR/data/"*.json "$DATA_DIR/data/"
chmod 644 "$DATA_DIR/data/"*.json

# ── Crear servicio systemd ────────────────────────────────────
info "Creando servicio systemd..."
cat > "$SERVICE_FILE" << 'SERVICE'
[Unit]
Description=PaoloMind — Sistema de Conciencia Artificial
Documentation=https://paolos.software
After=network.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/opt/paolosmind/paolosmind
WorkingDirectory=/var/paolosmind
StandardOutput=append:/var/paolosmind/logs/paolosmind.log
StandardError=append:/var/paolosmind/logs/paolosmind_error.log
Restart=on-failure
RestartSec=5
Environment="RUST_LOG=info"
Environment="PAOLOSMIND_DATA=/var/paolosmind"

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable paolosmind 2>/dev/null || warn "systemd no disponible"

# ── Crear wrapper de conveniencia ─────────────────────────────
cat > /usr/local/bin/paolosmind-start << 'WRAPPER'
#!/bin/bash
echo "🧠 Iniciando PaoloMind..."
/opt/paolosmind/paolosmind "$@"
WRAPPER
chmod +x /usr/local/bin/paolosmind-start

# ── Verificar instalación ─────────────────────────────────────
info "Verificando instalación..."
if "$INSTALL_DIR/paolosmind" --version 2>/dev/null || \
   "$INSTALL_DIR/paolosmind" 2>&1 | head -3 | grep -q "PaoloMind"; then
    echo ""
    echo "╔══════════════════════════════════════════════╗"
    echo "║      ✅ PaoloMind instalado exitosamente     ║"
    echo "║                                              ║"
    echo "║  Binario:  /opt/paolosmind/paolosmind        ║"
    echo "║  Datos:    /var/paolosmind/data/             ║"
    echo "║  Logs:     /var/paolosmind/logs/             ║"
    echo "║                                              ║"
    echo "║  Ejecutar:  paolosmind                       ║"
    echo "║  Servicio:  systemctl start paolosmind       ║"
    echo "╚══════════════════════════════════════════════╝"
else
    warn "Verificación automática no concluyente — prueba: paolosmind"
fi
