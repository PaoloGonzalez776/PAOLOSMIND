# PaoloMind v1.0 — PaolosSoftware © 2026

Sistema de conciencia artificial con 22 módulos en 6 capas cognitivas.
Binario nativo para Ubuntu 22.04 / 24.04 x86_64.

## Instalación rápida

```bash
sudo bash scripts/install.sh
```

## Uso directo (sin instalar)

```bash
chmod +x bin/paolosmind
sudo mkdir -p /var/paolosmind/data
sudo cp data/*.json /var/paolosmind/data/
./bin/paolosmind
```

## Como servicio systemd

```bash
sudo systemctl start paolosmind
sudo systemctl status paolosmind
sudo journalctl -u paolosmind -f
```

## Estructura de archivos

```
bin/paolosmind              → Binario ELF x86-64 (577KB, stripped)
data/vocabulario_base.json  → 120 palabras base en español
data/bash_commands.json     → 48 comandos bash con flags y ejemplos
data/conocimiento_causal.json → 43 relaciones causales primarias
scripts/install.sh          → Instalador automático Ubuntu
```

## Capas cognitivas

| # | Capa          | Módulos                                        |
|---|---------------|------------------------------------------------|
| 1 | Percepción    | texto, visual (OCR), audio                     |
| 2 | Comprensión   | lenguaje español, bash parser, filtro          |
| 3 | Razonamiento  | inferencia causal, contradicciones, curiosidad |
| 4 | Conciencia    | identidad, metacognición, tiempo, sueño        |
| 5 | Memoria       | working, episódica, semántica, procedimental   |
| 6 | Acción        | bash executor, navegador, YouTube, social      |

## Datos en runtime

- `/var/paolosmind/data/`   → JSONs de conocimiento
- `/var/paolosmind/memory/` → Bases de datos SQLite
- `/var/paolosmind/logs/`   → Logs de operación
