#!/bin/bash
set -e

echo "🚀 Iniciando PaoloMind v1.0 en modo automático..."

# Asegurar que los directorios de datos existan con permisos correctos
sudo mkdir -p /var/paolosmind/data /var/paolosmind/memory /var/paolosmind/logs
sudo chown -R paolosmind:paolosmind /var/paolosmind

# Verificar presencia de archivos de conocimiento
if [ ! -f /var/paolosmind/data/vocabulario_base.json ]; then
    echo "⚠️  Datos de conocimiento no encontrados en /var/paolosmind/data. Copiando base..."
    sudo cp /app/data/*.json /var/paolosmind/data/
fi

# Iniciar el binario de PaoloMind
echo "🧠 PaoloMind está despertando..."
exec /app/bin/paolosmind
